export default function indicadores() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-900 text-white">
      
      <div className="text-center px-6">

        <h1 className="text-5xl font-bold text-yellow-400">
          🚧 En desarrollo
        </h1>

        <p className="text-gray-300 mt-4 text-lg">
          Esta sección aún se está construyendo.
        </p>

        <p className="text-gray-500 mt-2">
          Vuelve pronto 👷‍♂️
        </p>

      </div>

    </main>
  );
}