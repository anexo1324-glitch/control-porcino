"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";

const DIAS_GESTACION = 114;

export default function CerdaDetalle() {
  const { id } = useParams();
  const router = useRouter();

  const [cerda, setCerda] = useState<any>(null);
  const [registros, setRegistros] = useState<any[]>([]);

  const [mostrarForm, setMostrarForm] = useState(false);

  const [tipo, setTipo] = useState("Inseminación");
  const [fecha, setFecha] = useState("");
  const [descripcion, setDescripcion] = useState("");

  useEffect(() => {
    const datos = JSON.parse(
      localStorage.getItem("cerdas") || "[]"
    );

    const encontrada = datos.find(
      (c: any) => c.id === id
    );

    setCerda(encontrada);

    const hist = JSON.parse(
      localStorage.getItem(
        `historial-${id}`
      ) || "[]"
    );

    setRegistros(hist);

  }, [id]);

  function guardar(nuevos: any[]) {
    setRegistros(nuevos);

    localStorage.setItem(
      `historial-${id}`,
      JSON.stringify(nuevos)
    );
  }

  function calcularParto(
    fechaInseminacion: string
  ) {
    const f = new Date(fechaInseminacion);

    f.setDate(
      f.getDate() + DIAS_GESTACION
    );

    return f
      .toISOString()
      .split("T")[0];
  }

  function agregarRegistro() {
    if (!fecha) return;

    let nuevo: any = {
      tipo,
      fecha,
      descripcion,
    };

    // INSEMINACIÓN
    if (tipo === "Inseminación") {
      nuevo.partoEstimado =
        calcularParto(fecha);
    }

    // ABORTO
    if (tipo === "Aborto") {
      nuevo.mensaje =
        "Reiniciar ciclo reproductivo";
    }

    // BAJA
    if (tipo === "Baja") {
      nuevo.mensaje =
        "Cerda dada de baja";
    }

    // PARTO
    if (tipo === "Parto") {
      nuevo.mensaje =
        "Cerda en lactancia";
    }

    // DESTETE
    if (tipo === "Destete") {
      nuevo.mensaje =
        "Fin etapa lactancia";
    }

    const nuevos = [
      ...registros,
      nuevo,
    ];

    guardar(nuevos);

    setMostrarForm(false);

    setFecha("");
    setDescripcion("");
  }

  if (!cerda) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-[#f5f5f7] text-black">
        <p>Cerda no encontrada</p>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#f5f5f7] p-4">

      <div className="max-w-md mx-auto">

        {/* HEADER */}
        <div className="flex items-center justify-between mb-6">

          <button
            onClick={() => router.back()}
            className="
              bg-white
              shadow
              border
              border-gray-200
              px-4
              py-2
              rounded-2xl
              text-black
            "
          >
            ←
          </button>

          <h1 className="text-2xl font-black text-black">
            {cerda.id}
          </h1>

          <div className="w-10"></div>

        </div>

        {/* INFO */}
        <div
          className="
            bg-white
            rounded-3xl
            p-5
            shadow-md
            border
            border-pink-100
          "
        >

          <div className="flex items-center justify-between">

            <div>

              <h2 className="text-2xl font-bold text-black">
                {cerda.raza}
              </h2>

              <p className="text-gray-500 mt-1">
                {cerda.estado}
              </p>

            </div>

            <span
              className="
                bg-pink-500
                text-white
                px-3
                py-1
                rounded-xl
                text-sm
                font-bold
              "
            >
              ACTIVA
            </span>

          </div>

          <div className="mt-4">

            <p className="text-sm text-gray-500">
              Características
            </p>

            <p className="text-black mt-1">
              {cerda.caracteristicas}
            </p>

          </div>

        </div>

        {/* HISTORIAL */}
        <div className="mt-6">

          <div className="flex items-center justify-between mb-4">

            <h2 className="text-xl font-bold text-black">
              Historial
            </h2>

            <button
              onClick={() =>
                setMostrarForm(true)
              }
              className="
                bg-pink-500
                text-white
                px-4
                py-2
                rounded-2xl
                font-bold
              "
            >
              +
            </button>

          </div>

          <div className="space-y-3">

            {registros.length === 0 && (

              <div
                className="
                  bg-white
                  rounded-2xl
                  p-5
                  text-center
                  text-gray-500
                  border
                  border-gray-200
                "
              >
                Sin registros
              </div>

            )}

            {registros.map((r, i) => (

              <div
                key={i}
                className="
                  bg-white
                  rounded-3xl
                  p-4
                  shadow-sm
                  border
                  border-gray-200
                "
              >

                <div className="flex justify-between items-start">

                  <div>

                    <h3 className="font-bold text-black">
                      {r.tipo}
                    </h3>

                    <p className="text-sm text-gray-500 mt-1">
                      {r.fecha}
                    </p>

                  </div>

                  <div
                    className="
                      bg-pink-100
                      text-pink-600
                      text-xs
                      font-bold
                      px-3
                      py-1
                      rounded-full
                    "
                  >
                    Registro
                  </div>

                </div>

                {r.partoEstimado && (

                  <div
                    className="
                      mt-3
                      bg-green-50
                      border
                      border-green-200
                      p-3
                      rounded-2xl
                    "
                  >

                    <p className="text-green-700 text-sm font-medium">
                      Parto estimado
                    </p>

                    <p className="text-green-900 font-bold">
                      {r.partoEstimado}
                    </p>

                  </div>

                )}

                {r.descripcion && (

                  <p className="text-gray-700 mt-3 text-sm">
                    {r.descripcion}
                  </p>

                )}

                {r.mensaje && (

                  <div
                    className="
                      mt-3
                      bg-yellow-50
                      border
                      border-yellow-200
                      p-3
                      rounded-2xl
                    "
                  >

                    <p className="text-yellow-800 text-sm">
                      {r.mensaje}
                    </p>

                  </div>

                )}

              </div>

            ))}

          </div>

        </div>

      </div>

      {/* MODAL */}
      {mostrarForm && (

        <div
          className="
            fixed
            inset-0
            bg-black/40
            flex
            items-center
            justify-center
            p-4
            z-50
          "
        >

          <div
            className="
              bg-white
              w-full
              max-w-md
              rounded-3xl
              p-6
            "
          >

            <h2 className="text-2xl font-bold text-black mb-5">
              Nuevo registro
            </h2>

            {/* TIPO */}
            <select
              value={tipo}
              onChange={(e) =>
                setTipo(e.target.value)
              }
              className="
                w-full
                h-14
                px-4
                rounded-2xl
                bg-gray-100
                border
                border-gray-300
                outline-none
                text-black
                mb-4
              "
            >
              <option>
                Inseminación
              </option>

              <option>
                Celo
              </option>

              <option>
                Parto
              </option>

              <option>
                Destete
              </option>

              <option>
                Aborto
              </option>

              <option>
                Baja
              </option>

              <option>
                Tratamiento
              </option>

            </select>

            {/* FECHA */}
            <div className="mb-4">

              <p className="text-sm mb-2 text-gray-500">
                Fecha
              </p>

              <input
                type="date"
                value={fecha}
                onChange={(e) =>
                  setFecha(
                    e.target.value
                  )
                }
                className="
                  w-full
                  h-14
                  px-4
                  rounded-2xl
                  bg-gray-100
                  border
                  border-gray-300
                  outline-none
                  text-black
                  appearance-none
                "
              />

            </div>

            {/* DESCRIPCIÓN */}
            <textarea
              placeholder="Descripción"
              value={descripcion}
              onChange={(e) =>
                setDescripcion(
                  e.target.value
                )
              }
              className="
                w-full
                h-24
                px-4
                py-3
                rounded-2xl
                bg-gray-100
                border
                border-gray-300
                outline-none
                text-black
                resize-none
                mb-4
              "
            />

            {/* BOTONES */}
            <button
              onClick={agregarRegistro}
              className="
                w-full
                bg-pink-500
                text-white
                py-4
                rounded-2xl
                font-bold
              "
            >
              Guardar
            </button>

            <button
              onClick={() =>
                setMostrarForm(false)
              }
              className="
                w-full
                bg-gray-200
                text-black
                py-4
                rounded-2xl
                mt-3
              "
            >
              Cancelar
            </button>

          </div>

        </div>

      )}

    </main>
  );
}