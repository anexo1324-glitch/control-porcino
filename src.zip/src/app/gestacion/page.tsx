"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function Gestacion() {
  const router = useRouter();

  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [buscar, setBuscar] = useState("");

  const [menuIndex, setMenuIndex] = useState<number | null>(null);
  const [editIndex, setEditIndex] = useState<number | null>(null);

  const [id, setId] = useState("");
  const [raza, setRaza] = useState("Camborough");
  const [otraRaza, setOtraRaza] = useState("");
  const [fecha, setFecha] = useState("");
  const [caracteristicas, setCaracteristicas] = useState("");

  const [cerdas, setCerdas] = useState<any[]>([]);

  useEffect(() => {
    const datos = JSON.parse(
      localStorage.getItem("cerdas") || "[]"
    );

    setCerdas(datos);
  }, []);

  // CERRAR MENÚ AL TOCAR FUERA
  useEffect(() => {
    function handleClickOutside() {
      setMenuIndex(null);
    }

    if (menuIndex !== null) {
      document.addEventListener(
        "click",
        handleClickOutside
      );
    }

    return () => {
      document.removeEventListener(
        "click",
        handleClickOutside
      );
    };
  }, [menuIndex]);

  function guardar(nuevas: any[]) {
    setCerdas(nuevas);

    localStorage.setItem(
      "cerdas",
      JSON.stringify(nuevas)
    );
  }

  function resetForm() {
    setId("");
    setRaza("Camborough");
    setOtraRaza("");
    setFecha("");
    setCaracteristicas("");
    setEditIndex(null);
  }

  function eliminarCerda(index: number) {
    const confirmar = confirm(
      "¿Confirmas eliminar cerda?"
    );

    if (!confirmar) return;

    const nuevas = cerdas.filter(
      (_, i) => i !== index
    );

    guardar(nuevas);

    setMenuIndex(null);
  }

  function editarCerda(index: number) {
    const c = cerdas[index];

    const razasBase = [
      "Camborough",
      "Landrace",
      "Large White",
      "Yorkshire",
      "Duroc",
      "Pietrain",
      "Hampshire",
    ];

    setId(c.id);

    setRaza(
      razasBase.includes(c.raza)
        ? c.raza
        : "OTRA"
    );

    setOtraRaza(
      razasBase.includes(c.raza)
        ? ""
        : c.raza
    );

    setFecha(c.fecha);

    setCaracteristicas(
      c.caracteristicas
    );

    setEditIndex(index);

    setMostrarFormulario(true);

    setMenuIndex(null);
  }

  function agregarOCrear() {
    const razaFinal =
      raza === "OTRA"
        ? otraRaza
        : raza;

    if (!id || !razaFinal) return;

    const nueva = {
      id: id.toUpperCase(),
      raza: razaFinal,
      fecha,
      caracteristicas,
      estado: "GESTACIÓN",
    };

    if (editIndex !== null) {
      const confirmar = confirm(
        "¿Confirmas actualizar cerda?"
      );

      if (!confirmar) return;

      const nuevas = [...cerdas];

      nuevas[editIndex] = nueva;

      guardar(nuevas);

    } else {

      guardar([
        ...cerdas,
        nueva,
      ]);
    }

    setMostrarFormulario(false);

    resetForm();
  }

  const filtradas = cerdas.filter(
    (c) =>
      (c.id || "")
        .toLowerCase()
        .includes(
          buscar.toLowerCase()
        )
  );

  return (
    <main className="min-h-screen bg-white text-black p-4">

      <div className="max-w-md mx-auto">

        {/* HEADER */}
        <div className="mb-6">

          <h1 className="text-4xl font-bold text-pink-600">
            Gestación
          </h1>

          <p className="text-gray-600 mt-2">
            Inventario hembras
          </p>

        </div>

        {/* BUSCADOR */}
        <input
          type="text"
          placeholder="Buscar ID..."
          value={buscar}
          onChange={(e) =>
            setBuscar(e.target.value)
          }
          className="
            w-full
            p-4
            rounded-2xl
            bg-gray-100
            border
            border-gray-300
            mb-6
            outline-none
            text-black
          "
        />

        {/* CARDS */}
        <div className="grid grid-cols-2 gap-3">

          {filtradas.map(
            (cerda, index) => (

              <div
                key={index}
                onClick={() =>
                  router.push(
                    `/cerda/${cerda.id}`
                  )
                }
                className="
                  relative
                  bg-white
                  rounded-2xl
                  p-4
                  border
                  border-pink-300
                  shadow-md
                  cursor-pointer
                  active:scale-95
                  transition
                "
              >

                {/* CONTENIDO */}
                <h2 className="text-lg font-bold">
                  {cerda.id}
                </h2>

                <p className="text-gray-600 text-sm">
                  {cerda.raza}
                </p>

                <span
                  className="
                    bg-yellow-400
                    text-black
                    px-2
                    py-1
                    rounded-lg
                    text-xs
                    font-bold
                    w-fit
                    mt-1
                    inline-block
                  "
                >
                  GESTACIÓN
                </span>

                <div className="mt-2 text-sm">

                  <p className="text-gray-600 text-xs">
                    Fecha llegada
                  </p>

                  <p>
                    {cerda.fecha}
                  </p>

                </div>

                <div className="mt-2 text-sm">

                  <p className="text-gray-600 text-xs">
                    Características
                  </p>

                  <p>
                    {cerda.caracteristicas}
                  </p>

                </div>

                {/* BOTÓN ⋯ */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();

                    setMenuIndex(
                      menuIndex === index
                        ? null
                        : index
                    );
                  }}
                  className="
                    absolute
                    top-2
                    right-2
                    text-black
                    text-2xl
                    font-bold
                    px-2
                  "
                >
                  ⋯
                </button>

                {/* MENÚ */}
                {menuIndex === index && (

                  <div
                    onClick={(e) =>
                      e.stopPropagation()
                    }
                    className="
                      absolute
                      top-10
                      right-2
                      bg-white
                      border
                      border-gray-300
                      rounded-xl
                      shadow-lg
                      overflow-hidden
                      z-50
                      text-black
                    "
                  >

                    <button
                      onClick={() =>
                        editarCerda(index)
                      }
                      className="
                        block
                        px-4
                        py-2
                        text-sm
                        hover:bg-pink-100
                        w-full
                        text-left
                      "
                    >
                      Editar
                    </button>

                    <button
                      onClick={() =>
                        eliminarCerda(index)
                      }
                      className="
                        block
                        px-4
                        py-2
                        text-sm
                        hover:bg-red-100
                        w-full
                        text-left
                      "
                    >
                      Eliminar
                    </button>

                  </div>

                )}

              </div>

            )
          )}

        </div>

        {/* BOTÓN + */}
        <button
          onClick={() => {
            resetForm();

            setMostrarFormulario(true);
          }}
          className="
            fixed
            bottom-6
            right-6
            bg-pink-500
            text-white
            w-16
            h-16
            rounded-full
            text-4xl
            shadow-lg
          "
        >
          +
        </button>

        {/* FORMULARIO */}
        {mostrarFormulario && (

          <div
            className="
              fixed
              inset-0
              bg-black/40
              flex
              items-center
              justify-center
              p-4
            "
          >

            <div
              className="
                bg-white
                w-full
                max-w-md
                rounded-3xl
                p-6
                text-black
              "
            >

              <h2
                className="
                  text-3xl
                  font-bold
                  text-pink-600
                  mb-6
                "
              >
                {editIndex !== null
                  ? "Editar Cerda"
                  : "Nueva Cerda"}
              </h2>

              <div className="space-y-4">

                {/* ID */}
                <input
                  type="text"
                  placeholder="ID"
                  value={id}
                  onChange={(e) =>
                    setId(
                      e.target.value.toUpperCase()
                    )
                  }
                  className="
                    w-full
                    h-14
                    px-4
                    rounded-2xl
                    bg-gray-100
                    border
                    border-gray-300
                    outline-none
                    uppercase
                    text-black
                    placeholder:text-gray-500
                  "
                />

                {/* RAZA */}
                <select
                  value={raza}
                  onChange={(e) =>
                    setRaza(e.target.value)
                  }
                  className="
                    w-full
                    h-14
                    px-4
                    rounded-2xl
                    bg-gray-100
                    border
                    border-gray-300
                    outline-none
                    text-black
                  "
                >

                  <option value="Camborough">
                    Camborough
                  </option>

                  <option value="Landrace">
                    Landrace
                  </option>

                  <option value="Large White">
                    Large White
                  </option>

                  <option value="Yorkshire">
                    Yorkshire
                  </option>

                  <option value="Duroc">
                    Duroc
                  </option>

                  <option value="Pietrain">
                    Pietrain
                  </option>

                  <option value="Hampshire">
                    Hampshire
                  </option>

                  <option value="OTRA">
                    Otra
                  </option>

                </select>

                {/* OTRA RAZA */}
                {raza === "OTRA" && (

                  <input
                    type="text"
                    placeholder="Escribe la raza"
                    value={otraRaza}
                    onChange={(e) =>
                      setOtraRaza(
                        e.target.value
                      )
                    }
                    className="
                      w-full
                      h-14
                      px-4
                      rounded-2xl
                      bg-gray-100
                      border
                      border-gray-300
                      outline-none
                      text-black
                      placeholder:text-gray-500
                    "
                  />

                )}

                {/* FECHA */}
                <div>

                  <p className="text-sm mb-2 text-gray-600">
                    Fecha de llegada
                  </p>

                  <input
                    type="date"
                    value={fecha}
                    onChange={(e) =>
                      setFecha(
                        e.target.value
                      )
                    }
                    className="
                      w-full
                      h-14
                      px-4
                      rounded-2xl
                      bg-gray-100
                      border
                      border-gray-300
                      outline-none
                      text-black
                      appearance-none
                    "
                  />

                </div>

                {/* CARACTERÍSTICAS */}
                <textarea
                  value={caracteristicas}
                  onChange={(e) =>
                    setCaracteristicas(
                      e.target.value
                    )
                  }
                  placeholder="Características"
                  className="
                    w-full
                    h-20
                    px-4
                    py-3
                    rounded-2xl
                    bg-gray-100
                    border
                    border-gray-300
                    outline-none
                    text-black
                    resize-none
                    placeholder:text-gray-500
                  "
                />

                {/* BOTÓN */}
                <button
                  onClick={agregarOCrear}
                  className="
                    w-full
                    bg-pink-500
                    text-white
                    py-4
                    rounded-2xl
                    text-lg
                    font-bold
                  "
                >
                  {editIndex !== null
                    ? "Actualizar"
                    : "Agregar"}
                </button>

                {/* CANCELAR */}
                <button
                  onClick={() =>
                    setMostrarFormulario(false)
                  }
                  className="
                    w-full
                    bg-gray-300
                    py-4
                    rounded-2xl
                    text-lg
                    text-black
                  "
                >
                  Cancelar
                </button>

              </div>

            </div>

          </div>

        )}

      </div>

    </main>
  );
}